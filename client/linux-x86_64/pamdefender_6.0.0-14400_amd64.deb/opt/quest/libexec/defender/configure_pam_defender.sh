#!/bin/sh

##==============================================================================
# Copyright 2024 One Identity LLC. ALL RIGHTS RESERVED.
##
## Version: 6.0.0.14400
##
##==============================================================================

CONFIG_PAM="/opt/quest/libexec/defender/config_pam"
PLATFORM=`uname`
SOLARISID="SunOS"
HPUXID="HP-UX"
LINUXID="Linux"
AIXID="AIX"
DARWINID="Darwin"
FREEBSDID="FreeBSD"
MODULE_NAME="pam_defender"
#The pam service to copy if a configuration is missing
COPY_SOURCE="login"

if [ "`id | sed 's/uid=\([0-9]*\).*/\1/'`" -ne 0 ] ; then
    echo "You must have root access to configure pam authentication\n"
    exit 1
fi

usage()
{
   echo "Usage: configure_pam_defender.sh <pam_servicename> [add|remove]"
   exit 1
}

if [ "$1" = "" ] ; then
   usage
fi

if [ -f "/opt/quest/libexec/defender/configure_libmap_conf.sh" ]; then
   # Backup this script's parameters
   params="$@"
   # Set the parameters for the configure_libmap_conf script
   set -- "$MODULE_NAME.so" "load"
   # Load the configure_libmap_conf script
   # This can be dangerous if configure_libmap_conf overwrites any of this
   # script variables or functions
   . "/opt/quest/libexec/defender/configure_libmap_conf.sh"
   # Restore this script's original parameters
   set -- $params
fi

MODULEFLAG="requisite"
if [ "$PLATFORM" = "$HPUXID" ] ; then
    /usr/bin/grep -q requisite /usr/lib/libpam.sl
    if [ $? != 0 ]; then
        MODULEFLAG="required"
    fi
fi

# If there is not a configuration stack for the specified servicename
# create one (via copying a well known service) before proceeding
copy_service_if_missing()
{
    # skip include service names like common-auth they don't typically want to have entries
    # for each function class and they typically already exist.  If they don't already exist
    # we probably don't want to create them automatically.
    if [ "$SERVICE_NAME" = "common-auth" ] || [ "$SERVICE_NAME" = "common-account" ] ||
       [ "$SERVICE_NAME" = "common-session" ] || [ "$SERVICE_NAME" = "common-password" ] ||
       [ "$SERVICE_NAME" = "system-auth" ] ; then
        return 0
    fi
    SERVICE_NAME="$1"
    FACILITY="$2"
    $CONFIG_PAM LIST -s "$SERVICE_NAME" -c "$FACILITY" 1> /dev/null 2> /dev/null
    if [ $? != 0 ]; then
        $CONFIG_PAM COPY -t "$SERVICE_NAME" -c "$FACILITY" -s "$COPY_SOURCE"
    fi
}

unconfigure_defender_pam()
{
    SERVICE_NAME="$1"
    $CONFIG_PAM DELETE -s "$SERVICE_NAME" -m "$MODULE_NAME" -c auth
}

should_pam_for_service_and_facility()
{
    SERVICE_NAME="$1"

    if [ "$PLATFORM" = "$LINUXID" ] ; then
        #postlogin and postlogin-ac are Fedora modules that are generally empty, and
        #when we try to configure them we end up copying stuff from other, which
        #actually breaks login completely somehow
        #bug 24569 and 791172.
        if [ "$SERVICE_NAME" = "postlogin" ] || [ "$SERVICE_NAME" = "postlogin-ac" ] || [ "$SERVICE_NAME" = "fingerprint-auth" ] || [ "$SERVICE_NAME" = "fingerprint-auth-ac" ] ; then
            return 1
        fi
        if [ "$SERVICE_NAME" = "smartcard" ] || [ "$SERVICE_NAME" = "smartcard-ac" ] ; then
            if [ "$MODULE_NAME" != "$SMARTCARD_MOD_NAME" ]; then
                return 1
            fi
        fi
    fi

    # Bug 764742 - don't configure this service on Solaris, we mess it up since it
    # includes the service name unlike any other file.
    if [ "$SERVICE_NAME" = "pam_authtok_common" ] && [ "$PLATFORM" = "$SOLARISID" ]; then
        return 1;
    fi
}

configure_defender_pam()
{
    SERVICE_NAME="$1"

    should_pam_for_service_and_facility "$SERVICE_NAME"
    if [ $? != 0 ] ; then
        echo "Unable to configure service $SERVICE_NAME for pam defender authentication.\n"
        exit 0
    fi

    $CONFIG_PAM LIST -s "$SERVICE_NAME" -m "$MODULE_NAME" -c auth 1> /dev/null 2> /dev/null
    if [ $? = 0 ] ; then
        echo "The $MODULE_NAME module is already configured for service $SERVICE_NAME"
        exit 0
    fi

    copy_service_if_missing "$SERVICE_NAME" auth
    copy_service_if_missing "$SERVICE_NAME" account
    copy_service_if_missing "$SERVICE_NAME" session
    copy_service_if_missing "$SERVICE_NAME" password

    #Check for the service again, now that we have possibly copied a prexisting configuration
    $CONFIG_PAM LIST -s "$SERVICE_NAME" -m "$MODULE_NAME" -c auth 1> /dev/null 2> /dev/null
    if [ $? = 0 ] ; then
        echo "Successfully configured service $SERVICE_NAME for two factor authentication"
        exit 0
    fi
    #Stick ourselves before the pam_vas3 module if it is installed
    $CONFIG_PAM ADD -s "$SERVICE_NAME" -m "$MODULE_NAME" -c auth -f "$MODULEFLAG" -p BEFORE -r pam_vas3 1> /dev/null 2> /dev/null
    if [ $? = 0 ] ; then
        echo "Successfully configured service $SERVICE_NAME for two factor authentication"
        exit 0
    fi
    if [ "$PLATFORM" = "$SOLARISID" ] ; then
        #On Solaris stick ourselves before the authtok_get module, so we can prompt properly for a passcode
        $CONFIG_PAM ADD -s "$SERVICE_NAME" -m "$MODULE_NAME" -c auth -f "$MODULEFLAG" -p BEFORE -r pam_authtok_get 1> /dev/null 2> /dev/null
        if [ $? = 0 ] ; then
            echo "Successfully configured service $SERVICE_NAME for two factor authentication"
            exit 0
        fi
    fi 
    if [ "$PLATFORM" = "$AIXID" ] ; then
        $CONFIG_PAM ADD -s "$SERVICE_NAME" -m "$MODULE_NAME" -c auth -f "$MODULEFLAG" -p BEFORE -r pam_aix 1> /dev/null 2> /dev/null
        if [ $? = 0 ] ; then
            echo "Successfully configured service $SERVICE_NAME for two factor authentication"
            exit 0
        fi
    fi
    if [ "$PLATFORM" = "$DARWINID" ] ; then
        $CONFIG_PAM ADD -s "$SERVICE_NAME" -m "$MODULE_NAME" -c auth -f "$MODULEFLAG" -p BEFORE -r pam_opendirectory 1> /dev/null 2> /dev/null
        if [ $? = 0 ] ; then
            echo "Successfully configured service $SERVICE_NAME for two factor authentication"
            exit 0
        fi
        $CONFIG_PAM ADD -s "$SERVICE_NAME" -m "$MODULE_NAME" -c auth -f "$MODULEFLAG" -p BEFORE -r pam_securityserver 1> /dev/null 2> /dev/null
        if [ $? = 0 ] ; then
            echo "Successfully configured service $SERVICE_NAME for two factor authentication"
            exit 0
        fi
    fi
    $CONFIG_PAM ADD -s "$SERVICE_NAME" -m "$MODULE_NAME" -c auth -f "$MODULEFLAG" -p BEFORE -r pam_unix 1> /dev/null 2> /dev/null
    if [ $? = 0 ] ; then
        echo "Successfully configured service $SERVICE_NAME for two factor authentication"
        exit 0
    fi
    $CONFIG_PAM ADD -s "$SERVICE_NAME" -m "$MODULE_NAME" -c auth -f "$MODULEFLAG" -p BEFORE -r pam_unix2 1> /dev/null 2> /dev/null
    if [ $? = 0 ] ; then
        echo "Successfully configured service $SERVICE_NAME for two factor authentication"
        exit 0
    fi
    $CONFIG_PAM ADD -s "$SERVICE_NAME" -m "$MODULE_NAME" -c auth -f "$MODULEFLAG" -p BEFORE -r pam_unix_auth 1> /dev/null 2> /dev/null
    if [ $? = 0 ] ; then
        echo "Successfully configured service $SERVICE_NAME for two factor authentication"
        exit 0
    fi
    echo "Unable to find appropriate pam module to configure defender before.  Defender pam NOT successfully configured for $SERVICE_NAME" 
    if [ ! -f /etc/pam_radius_acl.conf ] ; then
        touch /etc/pam_radius_acl.conf
    fi
    exit 1
}

$CONFIG_PAM LINK -m "$MODULE_NAME" -l "/opt/quest" 1> /dev/null 2> /dev/null
if [ "$2" = "add" ] ; then
	if [ "$PLATFORM" = "$FREEBSDID" ] ; then
        configure_libmap_conf && configure_defender_pam "$1"
	else
	    configure_defender_pam "$1"
	fi
else
    if [ "$2" = "remove" ] ; then
        unconfigure_defender_pam "$1"
        if [ $? != 0 ]; then
            echo "Service $SERVICE_NAME did not appear to be configured for two factor authentication\n"
        fi
    else
        usage
    fi
fi


